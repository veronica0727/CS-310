// Author: Veronica Marquez

#include<iostream>

using namespace std;

int main()
{
    /* declaring variables to hold the weather station name, temp,
    wind speed and direction */
    string weather_station, wind_direction;
    double temperature;
    int wind_speed;

    //assigning some values to the variables
    weather_station = "Kansas City";
    temperature = 78;
    wind_speed = 25;
    wind_direction = "South West";

    //printing the variables
    cout << "The " << weather_station << " Weather Station" << endl;

    cout << temperature << " degree F" << endl;

    cout << wind_speed << " " << wind_direction << endl;

    return 0;


}